WXCoin is a cool new crypto currency that will feature a uniquely implemented anonymization feature that uses exchanges on the back end and a decoupled transaction flow architecture.

This wallet supports the staking=0 option in the WXCoin.conf file to disable the stake miner thread for pool and exchange operators.

