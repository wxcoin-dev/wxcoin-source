#ifndef URITESTS_H
#define URITESTS_H

#include <QTest>
#include <QObject>

class URITests : public QObject
{
    Q_OBJECT

private slots:
    void uriTests();
};

#endif // URITESTS_H
